# Benchmark comparison

Results from the JSON reports in this directory. Evaluation IoU threshold: **0.5**. Spatial metrics are means over matched detections. Overall metrics come from the pooled corpus report, not averages of source scores.

Blank cells mean not run; N/A means a metric is undefined. Bold marks the best displayed available value, including ties at three decimal places. Compare only runs using the same document selection and renderer.

## Figure overall

| Category | Metric | TF-ID-Large | DocLayout-YOLO | YOLOv11 medium | YOLOv26 medium |
|---|---|---:|---:|---:|---:|
| Detection | Precision |  | **0.587** | 0.405 | 0.411 |
| Detection | Recall |  | **0.802** | 0.772 | 0.731 |
| Spatial Accuracy | IoU |  | 0.815 | **0.816** | 0.815 |
| Spatial Accuracy | Area Precision |  | **0.996** | 0.989 | 0.989 |
| Spatial Accuracy | Area Recall |  | 0.819 | **0.826** | 0.825 |

## Table overall

| Category | Metric | TF-ID-Large | DocLayout-YOLO | YOLOv11 medium | YOLOv26 medium |
|---|---|---:|---:|---:|---:|
| Detection | Precision |  | 0.474 | **0.503** | 0.468 |
| Detection | Recall |  | 0.886 | 0.885 | **0.902** |
| Spatial Accuracy | IoU |  | **0.838** | 0.822 | 0.831 |
| Spatial Accuracy | Area Precision |  | 0.993 | **0.995** | 0.994 |
| Spatial Accuracy | Area Recall |  | **0.845** | 0.826 | 0.836 |

## Figure by corpus

| Corpus | Category | Metric | TF-ID-Large | DocLayout-YOLO | YOLOv11 medium | YOLOv26 medium |
|---|---|---|---:|---:|---:|---:|
| UNHCR / ReliefWeb | Detection | Precision |  | **0.590** | 0.420 | 0.422 |
| UNHCR / ReliefWeb | Detection | Recall |  | **0.788** | 0.762 | 0.715 |
| UNHCR / ReliefWeb | Spatial Accuracy | IoU |  | 0.815 | **0.816** | 0.815 |
| UNHCR / ReliefWeb | Spatial Accuracy | Area Precision |  | **0.995** | 0.987 | 0.988 |
| UNHCR / ReliefWeb | Spatial Accuracy | Area Recall |  | 0.820 | **0.827** | 0.826 |
| PRWP | Detection | Precision |  | **0.689** | 0.487 | 0.465 |
| PRWP | Detection | Recall |  | 0.877 | 0.857 | **0.896** |
| PRWP | Spatial Accuracy | IoU |  | 0.800 | **0.818** | 0.808 |
| PRWP | Spatial Accuracy | Area Precision |  | **0.999** | **0.999** | 0.994 |
| PRWP | Spatial Accuracy | Area Recall |  | 0.800 | **0.819** | 0.813 |
| Refugee PADs | Detection | Precision |  | **0.330** | 0.118 | 0.124 |
| Refugee PADs | Detection | Recall |  | **0.968** | 0.710 | 0.516 |
| Refugee PADs | Spatial Accuracy | IoU |  | **0.895** | 0.820 | 0.879 |
| Refugee PADs | Spatial Accuracy | Area Precision |  | 0.997 | **0.999** | 0.988 |
| Refugee PADs | Spatial Accuracy | Area Recall |  | **0.898** | 0.821 | 0.890 |

## Table by corpus

| Corpus | Category | Metric | TF-ID-Large | DocLayout-YOLO | YOLOv11 medium | YOLOv26 medium |
|---|---|---|---:|---:|---:|---:|
| UNHCR / ReliefWeb | Detection | Precision |  | **0.498** | 0.472 | 0.408 |
| UNHCR / ReliefWeb | Detection | Recall |  | 0.931 | **0.954** | **0.954** |
| UNHCR / ReliefWeb | Spatial Accuracy | IoU |  | **0.886** | 0.859 | 0.877 |
| UNHCR / ReliefWeb | Spatial Accuracy | Area Precision |  | 0.997 | 0.995 | **0.999** |
| UNHCR / ReliefWeb | Spatial Accuracy | Area Recall |  | **0.889** | 0.864 | 0.878 |
| PRWP | Detection | Precision |  | 0.701 | **0.715** | 0.698 |
| PRWP | Detection | Recall |  | 0.923 | **0.942** | 0.938 |
| PRWP | Spatial Accuracy | IoU |  | **0.815** | 0.811 | 0.810 |
| PRWP | Spatial Accuracy | Area Precision |  | 0.998 | **0.999** | 0.998 |
| PRWP | Spatial Accuracy | Area Recall |  | **0.817** | 0.812 | 0.812 |
| Refugee PADs | Detection | Precision |  | 0.318 | **0.359** | 0.343 |
| Refugee PADs | Detection | Recall |  | 0.814 | 0.773 | **0.827** |
| Refugee PADs | Spatial Accuracy | IoU |  | **0.839** | 0.812 | 0.828 |
| Refugee PADs | Spatial Accuracy | Area Precision |  | 0.985 | **0.990** | 0.986 |
| Refugee PADs | Spatial Accuracy | Area Recall |  | **0.854** | 0.820 | 0.841 |
