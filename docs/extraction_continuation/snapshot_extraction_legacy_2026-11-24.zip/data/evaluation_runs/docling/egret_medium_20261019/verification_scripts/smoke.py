"""Prepare assets or smoke-test native Docling Egret Medium on one complete PDF."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import resource
import time
from importlib.metadata import distributions
from pathlib import Path
from typing import Any

WORK = Path(__file__).resolve().parent
REPO = Path("/home/ajd/data-snapshot-annotation")
PDF = (
    REPO
    / "data/hf_datasets/data-snapshot/documents/unhcr"
    / "08072015_northgovernorateprofile.pdf"
)
MODEL = "docling-project/docling-layout-egret-medium"
REVISION = "77ede7cc7bed96d853c58f319734803d6ea2ea5c"
ARTIFACTS = Path("/tmp/docling-heron-1a7BNUMJ/artifacts")


def _write_json(path: Path, value: Any) -> None:
    """Write a new evidence file without replacing an existing one."""
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)


def _sha256(path: Path) -> str:
    """Hash an artifact with bounded memory on Python 3.10."""
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _validate_pages(pages: list[dict[str, Any]], expected: int) -> None:
    """Reject missing pages, invalid coordinates, or invalid confidences."""
    assert [page["page_no"] for page in pages] == list(range(1, expected + 1))
    for page in pages:
        width, height = page["width"], page["height"]
        assert width > 0 and height > 0
        for cluster in page["clusters"]:
            left, top, right, bottom = cluster["bbox_top_left"]
            assert all(math.isfinite(v) for v in (left, top, right, bottom))
            assert 0 <= left < right <= width + 1e-6
            assert 0 <= top < bottom <= height + 1e-6
            assert math.isfinite(cluster["confidence"])
            assert 0 <= cluster["confidence"] <= 1


def _self_check() -> None:
    """Check page and detection validation without loading model dependencies."""
    valid = [{"page_no": 1, "width": 10, "height": 20, "clusters": []}]
    _validate_pages(valid, 1)
    invalid = [
        ([], 1),
        (valid, 2),
        ([{**valid[0], "width": 0}], 1),
        (
            [
                {
                    **valid[0],
                    "clusters": [{"bbox_top_left": [0, 0, 11, 20], "confidence": 0.5}],
                }
            ],
            1,
        ),
        (
            [
                {
                    **valid[0],
                    "clusters": [
                        {"bbox_top_left": [0, 0, 10, 20], "confidence": float("nan")}
                    ],
                }
            ],
            1,
        ),
    ]
    for pages, expected in invalid:
        try:
            _validate_pages(pages, expected)
        except AssertionError:
            continue
        raise AssertionError("Invalid smoke evidence passed validation")
    print("Smoke validation self-check passed.")


def _converter(device: str) -> Any:
    """Initialize the pinned native PDF pipeline using local artifacts only."""
    from docling.datamodel.accelerator_options import AcceleratorOptions
    from docling.datamodel.base_models import InputFormat
    from docling.datamodel.object_detection_engine_options import (
        TransformersObjectDetectionEngineOptions,
    )
    from docling.datamodel.pipeline_options import (
        LayoutObjectDetectionOptions,
        PdfPipelineOptions,
        RapidOcrOptions,
    )
    from docling.document_converter import DocumentConverter, PdfFormatOption

    layout = LayoutObjectDetectionOptions.from_preset("layout_egret_medium")
    layout.model_spec = layout.model_spec.model_copy(update={"revision": REVISION})
    layout.engine_options = TransformersObjectDetectionEngineOptions(
        torch_dtype="float32", compile_model=False
    )
    options = PdfPipelineOptions(
        artifacts_path=ARTIFACTS,
        accelerator_options=AcceleratorOptions(device=device, num_threads=4),
        layout_options=layout,
        do_ocr=True,
        ocr_options=RapidOcrOptions(
            backend="onnxruntime",
            lang=["en"],
            rapidocr_params={
                "EngineConfig.onnxruntime.use_cuda": False,
                "Det.use_cuda": False,
                "Cls.use_cuda": False,
                "Rec.use_cuda": False,
            },
        ),
        do_table_structure=False,
        generate_page_images=True,
        images_scale=2.0,
        layout_batch_size=1,
        ocr_batch_size=1,
        table_batch_size=1,
    )
    return DocumentConverter(
        allowed_formats=[InputFormat.PDF],
        format_options={InputFormat.PDF: PdfFormatOption(pipeline_options=options)},
    )


def _prepare() -> None:
    """Download Heron and English OCR assets, then verify initialization only."""
    from docling.datamodel.base_models import InputFormat
    from docling.models.stages.ocr.rapid_ocr_model import RapidOcrModel
    from huggingface_hub import snapshot_download

    ARTIFACTS.mkdir(exist_ok=True)
    snapshot_download(
        repo_id=MODEL,
        revision=REVISION,
        local_dir=ARTIFACTS / MODEL.replace("/", "--"),
        allow_patterns=["*.json", "*.safetensors"],
    )
    RapidOcrModel.download_models(
        backend="onnxruntime",
        lang="en",
        local_dir=ARTIFACTS / "RapidOcr",
        progress=True,
    )
    os.environ["HF_HUB_OFFLINE"] = "1"
    _converter("cpu").initialize_pipeline(InputFormat.PDF)
    manifest = {
        "model": MODEL,
        "revision": REVISION,
        "packages": sorted(
            f"{package.metadata['Name']}=={package.version}"
            for package in distributions()
        ),
        "artifacts_sha256": {
            str(path.relative_to(ARTIFACTS)): _sha256(path)
            for path in sorted(ARTIFACTS.rglob("*"))
            if path.is_file() and ".cache" not in path.parts
        },
    }
    _write_json(WORK / "prepared.json", manifest)
    print(f"PREPARED: {WORK / 'prepared.json'}; no PDF inference performed.")


def _run(device: str) -> None:
    """Process both PDF pages and retain native detections, links, and crops."""
    import torch
    from docling.datamodel.base_models import ConversionStatus
    from PIL import ImageDraw

    if (
        _sha256(ARTIFACTS / MODEL.replace("/", "--") / "model.safetensors")
        != "e7fc5b9a353826c123c5d03efc230909ac02b93e26293ec7cb4db8978fe9e3af"
    ):
        raise ValueError("Egret weights do not match pinned revision")
    if device.startswith("cuda") and not torch.cuda.is_available():
        raise RuntimeError("CUDA unavailable; no automatic CPU fallback.")
    print(Path("/proc/meminfo").read_text().split("SwapCached:")[0], flush=True)
    output = WORK / f"smoke-{time.time_ns()}"
    output.mkdir()
    if device.startswith("cuda"):
        torch.cuda.init()
        torch.cuda.reset_peak_memory_stats(device)
        props = torch.cuda.get_device_properties(device)
        print(f"GPU: {props.name}; VRAM: {props.total_memory / 2**30:.2f} GiB")
    start = time.perf_counter()
    converter = _converter(device)
    result = converter.convert(PDF)
    if device.startswith("cuda"):
        torch.cuda.synchronize(device)
    elapsed = time.perf_counter() - start
    if result.status != ConversionStatus.SUCCESS or result.errors:
        raise RuntimeError(f"Conversion incomplete: {result.status}; {result.errors}")
    pages = []
    for page in result.pages:
        clusters = []
        if page.predictions.layout is None:
            raise RuntimeError(f"No native layout output for page {page.page_no}")
        image = result.document.pages[page.page_no].image.pil_image.copy()
        draw = ImageDraw.Draw(image)
        for cluster in page.predictions.layout.clusters:
            bbox = cluster.bbox.to_top_left_origin(page_height=page.size.height)
            box = list(bbox.as_tuple())
            clusters.append(
                {
                    "native_id": cluster.id,
                    "label": cluster.label.value,
                    "confidence": cluster.confidence,
                    "bbox_top_left": box,
                }
            )
            if cluster.label.value in {"picture", "table"}:
                pixel_box = [
                    box[0] * image.width / page.size.width,
                    box[1] * image.height / page.size.height,
                    box[2] * image.width / page.size.width,
                    box[3] * image.height / page.size.height,
                ]
                draw.rectangle(pixel_box, outline="red", width=3)
                draw.text(
                    pixel_box[:2],
                    f"{cluster.label.value} {cluster.confidence:.3f}",
                    fill="red",
                )
        pages.append(
            {
                "page_no": page.page_no,
                "width": page.size.width,
                "height": page.size.height,
                "clusters": clusters,
            }
        )
        image.save(output / f"page-{page.page_no:03d}-bounds.png")
    _write_json(output / "native-layout.json", pages)
    _validate_pages(pages, expected=2)
    labels = {cluster["label"] for page in pages for cluster in page["clusters"]}
    assert {"picture", "table"} <= labels, f"Missing expected labels: {labels}"
    _write_json(output / "native-document.json", result.document.export_to_dict())
    links = []
    for item in [*result.document.pictures, *result.document.tables]:
        crop = item.get_image(result.document)
        if crop is None:
            raise RuntimeError(f"No native crop for {item.self_ref}")
        crop.save(output / (item.self_ref.lstrip("#/").replace("/", "-") + ".png"))
        links.append(
            {
                "native_ref": item.self_ref,
                "label": item.label.value,
                "provenance": [prov.model_dump(mode="json") for prov in item.prov],
                "captions": [ref.model_dump(mode="json") for ref in item.captions],
                "footnotes": [ref.model_dump(mode="json") for ref in item.footnotes],
                "crop_size": list(crop.size),
            }
        )
    _write_json(output / "native-links-and-crops.json", links)
    summary = {
        "pdf": str(PDF),
        "pages": len(pages),
        "model": MODEL,
        "revision": REVISION,
        "device": device,
        "precision": "float32",
        "elapsed_initialization_and_conversion_seconds": elapsed,
        "process_peak_rss_mib": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        / 1024,
        "torch_peak_allocated_mib": (
            torch.cuda.max_memory_allocated(device) / 2**20
            if device.startswith("cuda")
            else None
        ),
        "torch_peak_reserved_mib": (
            torch.cuda.max_memory_reserved(device) / 2**20
            if device.startswith("cuda")
            else None
        ),
        "ocr": "RapidOCR English ONNX Runtime CPU",
        "table_structure": False,
        "layout_batch_size": 1,
        "layout_stage": "native Docling layout output after its own postprocessing",
        "export_images_scale": 2.0,
        "area_filter": "none in diagnostic evidence; benchmark will use shared 0.008",
        "crop_policy": "native item.get_image; no caption or footnote expansion",
        "limitations": [
            "GPU peaks cover PyTorch allocator only, not driver/ONNX allocations.",
            "Visual inspection remains required.",
        ],
    }
    _write_json(output / "summary.json", summary)
    print(json.dumps(summary, indent=2))


def main() -> None:
    """Run asset preparation, offline smoke inference, or a dependency-free check."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=["prepare", "run", "self-check"])
    parser.add_argument("--device", default="cuda:0")
    args = parser.parse_args()
    if args.mode == "self-check":
        _self_check()
        return
    os.environ["HF_HOME"] = str(WORK / "hf-cache")
    os.environ["XDG_CACHE_HOME"] = str(WORK / "cache")
    os.environ["DOCLING_CACHE_DIR"] = str(WORK / "cache" / "docling")
    if args.mode == "prepare":
        _prepare()
    else:
        os.environ["HF_HUB_OFFLINE"] = "1"
        os.environ["TRANSFORMERS_OFFLINE"] = "1"
        _run(args.device)


if __name__ == "__main__":
    main()
