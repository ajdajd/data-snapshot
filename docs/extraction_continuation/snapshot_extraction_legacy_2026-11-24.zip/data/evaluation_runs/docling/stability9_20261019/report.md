# Native Docling Heron: nine-PDF stability and performance

Validated on 2026-10-19 using the exact `paper_benchmark_sample.json`: 9 PDFs,
170 pages, with 17 annotated Figures and 43 annotated Tables.

The tested runtime is the prepared Python 3.10 environment, Docling 2.140.0,
Transformers 5.20.1, Heron revision
`8f39ad3c0b4c58e9c2d2c84a38465abf757272d8`, FP32 on a GTX 1650 Ti (4 GiB),
English RapidOCR via CPU ONNX Runtime, and no table-structure/enrichment models.
Native layout processing and associations were retained. Evaluation keeps only
Figure/Table bounds and the shared normalized area threshold 0.008.

## Result

All nine baseline PDFs completed every page without conversion failures,
truncation, or out-of-memory errors. Prediction JSON passed schema v1.3 and
source/pooled evaluation had no document mismatches. The baseline retained 129
benchmark detections, 26 native caption links and five native footnote links.
All native references resolve; association correctness was not adjudicated.
Backend/OCR warnings remain in the captured logs.

| Setting | PDFs / pages | Time including initialization and native JSON export | Peak process RSS | PyTorch reserved VRAM |
|---|---:|---:|---:|---:|
| Serial, layout batch 1 | 9 / 170 | 652.26 s | 3547 MiB | 348 MiB |
| Serial, layout batch 4 | 9 / 170 | 705.47 s | 3483 MiB | 952 MiB |
| Serial, first-six subset | 6 / 61 | 206.27 s | Not isolated | Not isolated |
| Native document concurrency 2, layout batch 1 | 6 / 61 | 212.13 s | Not isolated | Not collected at stop |

Batch 4 was 8.2% slower in this trial. It preserved the same canonical IDs,
labels and detection counts. Maximum normalized bbox drift was 2.683e-7 and
confidence drift 4.989e-5. Native links and text were identical; native geometry
was not byte-identical. Detection precision/recall were identical, with tiny
floating-point differences in spatial means.

The concurrency trial was capped at the user's request after the first six
PDFs completed. It was 2.8% slower than those same six serial PDFs. All six
native document JSONs were identical. Two later PDFs were in flight when the
attempt was stopped; the attempt-wide RSS high-water mark was 4751 MiB and is
not a six-PDF-only peak. No final canonical prediction/confidence dump or GPU
allocator peak was collected for this interrupted trial. Completed native JSON
and progress/timing records are preserved. The process has been stopped.

These are single trials on this machine, not repeated statistical estimates.
Interpreter imports and evaluation are excluded from timings. Do not infer
full-corpus runtime or memory limits from this sample. Neither variant showed
a performance gain, so integration keeps serial documents and layout batch 1.

## Bounds metrics at IoU 0.5

| Label | Precision | Recall | Mean IoU | Mean area precision | Mean area recall |
|---|---:|---:|---:|---:|---:|
| Figure | 0.326 | 0.824 | 0.801 | 0.973 | 0.819 |
| Table | 0.465 | 0.930 | 0.795 | 0.985 | 0.810 |

Spatial means are over matched detections. These are sample diagnostics, not
half-benchmark results. Docling's backend and preprocessing differ from the
PyMuPDF baseline, so comparisons concern complete pipelines.

## Extra labels, native links, and crops

- `baseline/predictions.json`: schema v1.3 Figure/Table predictions only.
- `baseline/native-layout.json`: all 170 pages of native postprocessed clusters,
  with every emitted class, confidence, native ID and box.
- `baseline/native/<PDF>.json`: assembled native Docling document, text,
  provenance and caption/footnote references. This is not every raw proposal
  before Docling's own postprocessing.
- `native_crop_examples_verified/`: native `item.get_image(document)` crops,
  page overlays and exact caption geometry from the social-media report.
  The verified figure and table crops both exclude their native linked captions,
  which lie below the item bounds. No expansion or inferred association was used.
  Earlier `native_crop_examples/` output is an incomplete diagnostic attempt and
  must not be treated as evidence.
- The integrated adapter preserves assembled native JSON in
  `<prediction stem>.native/<PDF filename>.json`; the all-class layout dump is
  diagnostic-trial-only. The benchmark does not mass-export crops.

A crop can include text already inside its detected box. Native caption and
footnote references do not automatically enlarge the crop. Footnote references
were preserved and resolved on the nine-PDF sample; footnote crops were not
visually inspected in this check.

## Evidence and reproduction

`comparison.json`, each complete trial's `summary.json`, `reports/`, `progress/`,
`native/`, and the process logs retain the measurements. `run_environment.json`
records packages and model/OCR artifact SHA-256 values. The trial scripts are
included here. They use only local assets and refuse to replace existing trials.

The integration's focused suite passed 48 tests, plus Black, offline lockfile
validation and `git diff --check`. No new dependencies were installed by the
agent. The existing repository environment remains separate from the prepared
model environment.

The half-benchmark is intentionally left for the user. The ready local config
is `data/evaluation_runs/docling/user_run_config.json`, using the prepared
`/tmp/docling-heron-1a7BNUMJ` assets and a fresh user-run output directory.
Keep that temporary environment and assets intact through the full run.
