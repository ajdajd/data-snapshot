"""Compare trial timing, canonical detections, and native relationships exactly."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

ROOT = Path(
    "/home/ajd/data-snapshot-annotation/data/evaluation_runs/docling/stability9_20261019"
)


def _objects(data: dict[str, Any]) -> dict[str, dict[str, Any]]:
    """Index predictions by canonical ID without spatial association."""
    return {obj["id"]: obj for page in data["predictions"] for obj in page["objects"]}


def _links(document: dict[str, Any]) -> dict[str, Any]:
    """Retain exact native owner refs, linked refs, and linked text records."""
    return {
        "owners": {
            item["self_ref"]: {
                field: item.get(field, []) for field in ("captions", "footnotes")
            }
            for kind in ("pictures", "tables")
            for item in document[kind]
        },
        "texts": [
            {key: value for key, value in text.items() if key != "prov"}
            for text in document["texts"]
        ],
    }


def main() -> None:
    """Compare both complete trials and the explicitly capped parallel subset."""
    baseline = json.loads((ROOT / "baseline/predictions.json").read_text())
    original = _objects(baseline)
    summaries = []
    for mode in ("baseline", "batch4"):
        folder = ROOT / mode
        summary = json.loads((folder / "summary.json").read_text())
        predictions = json.loads((folder / "predictions.json").read_text())
        current = _objects(predictions)
        shared = original.keys() & current.keys()
        native_equal, links_equal = True, True
        for path in (ROOT / "baseline/native").glob("*.json"):
            native_a = json.loads(path.read_text())
            native_b = json.loads((folder / "native" / path.name).read_text())
            native_equal &= native_a == native_b
            links_equal &= _links(native_a) == _links(native_b)
        summary = {key: value for key, value in summary.items() if key != "completed"}
        summary.update(
            {
                "predictions_identical": baseline["predictions"]
                == predictions["predictions"],
                "canonical_ids_equal": original.keys() == current.keys(),
                "labels_equal_on_shared_ids": all(
                    original[key]["label"] == current[key]["label"] for key in shared
                ),
                "max_bbox_abs_difference_on_shared_ids": max(
                    (
                        abs(a - b)
                        for key in shared
                        for a, b in zip(
                            original[key]["bbox"], current[key]["bbox"], strict=True
                        )
                    ),
                    default=0,
                ),
                "max_score_abs_difference_on_shared_ids": max(
                    (
                        abs(original[key]["score"] - current[key]["score"])
                        for key in shared
                    ),
                    default=0,
                ),
                "native_documents_identical": native_equal,
                "native_links_and_text_identical": links_equal,
                "detection_count": len(current),
                "metrics": json.loads((folder / "reports/corpus.json").read_text())[
                    "metrics"
                ]["0.5"]["per_class"],
            }
        )
        summaries.append(summary)
    partial = ROOT / "parallel2"
    completed = [
        json.loads(path.read_text()) for path in partial.glob("progress/*.json")
    ]
    assert len(completed) == 6 and sum(row["pages"] for row in completed) == 61
    reference = json.loads((ROOT / "baseline/summary.json").read_text())
    ids = {row["doc_id"] for row in completed}
    baseline_seconds = max(
        row["elapsed_trial_seconds"]
        for row in reference["completed"]
        if row["doc_id"] in ids
    )
    elapsed = max(row["elapsed_trial_seconds"] for row in completed)
    identical = all(
        json.loads((ROOT / "baseline/native" / f"{doc_id}.json").read_text())
        == json.loads((partial / "native" / f"{doc_id}.json").read_text())
        for doc_id in ids
    )
    summaries.append(
        {
            "mode": "parallel2",
            "layout_batch_size": 1,
            "document_concurrency": 2,
            "documents": 6,
            "pages": 61,
            "subset_doc_ids": sorted(ids),
            "elapsed_init_convert_export_seconds": elapsed,
            "same_subset_baseline_seconds": baseline_seconds,
            "runtime_ratio_to_same_subset_baseline": elapsed / baseline_seconds,
            "native_documents_identical": identical,
            "native_links_and_text_identical": identical,
            "attempt_peak_process_rss_mib": 4865060 / 1024,
            "limits": "Stopped at user request after six completed PDFs; two later PDFs were in flight at interruption. Peak RSS covers that broader attempt. No final PyTorch memory peak or full canonical prediction dump was collected for this interrupted trial; native JSON is retained for each completed PDF.",
        }
    )
    with (ROOT / "comparison.json").open("x", encoding="utf-8") as stream:
        json.dump(summaries, stream, indent=2)
    print(json.dumps(summaries, indent=2))


if __name__ == "__main__":
    assert _objects(
        {"predictions": [{"objects": [{"id": "a", "label": "Figure"}]}]}
    ) == {"a": {"id": "a", "label": "Figure"}}
    assert _links(
        {
            "pictures": [
                {"self_ref": "#/pictures/0", "captions": [{"$ref": "#/texts/0"}]}
            ],
            "tables": [],
            "texts": [],
        }
    )["owners"]["#/pictures/0"]["captions"] == [{"$ref": "#/texts/0"}]
    main()
