"""Inspect native caption crops without rerunning OCR or layout inference."""

from __future__ import annotations

import json
from pathlib import Path

from docling.datamodel.base_models import InputFormat
from docling.datamodel.document import InputDocument
from docling.document_converter import PdfFormatOption
from docling_core.types.doc import DoclingDocument, ImageRef
from PIL import ImageDraw


def main() -> None:
    """Export native item crops and overlays for existing native caption links."""
    repo = Path("/home/ajd/data-snapshot-annotation")
    root = repo / "data/evaluation_runs/docling/stability9_20261019"
    name = "social_media_forced_displacement_europe_refugee_crises.pdf"
    document = DoclingDocument.model_validate_json(
        (root / "baseline/native" / f"{name}.json").read_text()
    )
    source = InputDocument(
        path_or_stream=repo / "data/hf_datasets/data-snapshot/documents/unhcr" / name,
        format=InputFormat.PDF,
        backend=PdfFormatOption().backend,
    )
    output = root / "native_crop_examples_verified"
    output.mkdir()
    records = []
    try:
        page_images = {}
        for backend in source._backend.iter_pages():
            page_images[backend.page_no] = backend.get_page_image(scale=2)
            backend.unload()
        assert set(page_images) == set(document.pages)
        for item in [*document.pictures, *document.tables]:
            if not item.captions:
                continue
            prov = item.prov[0]
            page = document.pages[prov.page_no]
            image = page_images[prov.page_no]
            page.image = ImageRef.from_pil(image, dpi=144)
            filename = item.self_ref.lstrip("#/").replace("/", "-")
            crop = item.get_image(document)
            assert crop is not None
            crop.save(output / f"{filename}.png")
            overlay = image.copy()
            draw = ImageDraw.Draw(overlay)
            bbox = prov.bbox.to_top_left_origin(page_height=page.size.height)
            draw.rectangle(
                bbox.scale_to_size(
                    old_size=page.size, new_size=page.image.size
                ).as_tuple(),
                outline="red",
                width=3,
            )
            caption_records = []
            for ref in item.captions:
                caption = ref.resolve(document)
                for caption_prov in caption.prov:
                    if caption_prov.page_no != prov.page_no:
                        continue
                    cb = caption_prov.bbox.to_top_left_origin(
                        page_height=page.size.height
                    )
                    draw.rectangle(
                        cb.scale_to_size(
                            old_size=page.size, new_size=page.image.size
                        ).as_tuple(),
                        outline="blue",
                        width=3,
                    )
                    caption_records.append(
                        {
                            "ref": ref.cref,
                            "text": caption.text,
                            "bbox_top_left": list(cb.as_tuple()),
                            "inside_item_bounds": bbox.l <= cb.l
                            and bbox.t <= cb.t
                            and bbox.r >= cb.r
                            and bbox.b >= cb.b,
                        }
                    )
            overlay.save(output / f"{filename}-page-overlay.png")
            records.append(
                {
                    "item_ref": item.self_ref,
                    "page_no": prov.page_no,
                    "bbox_top_left": list(bbox.as_tuple()),
                    "crop_size": list(crop.size),
                    "captions": caption_records,
                }
            )
    finally:
        source._backend.unload()
    assert len(records) == 2
    with (output / "examples.json").open("x", encoding="utf-8") as stream:
        json.dump(records, stream, indent=2)
    print(json.dumps(records, indent=2))


if __name__ == "__main__":
    main()
