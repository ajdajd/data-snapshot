"""Measure native Docling settings on the exact nine-PDF sample without downloads."""

from __future__ import annotations

import argparse
import json
import resource
import time
from pathlib import Path
from typing import Any

WORK = Path(__file__).resolve().parent
REPO = Path("/home/ajd/data-snapshot-annotation")
OUTPUT = REPO / "data/evaluation_runs/docling/stability9_20261019"
MODES = {"baseline": (1, 1), "batch4": (4, 1), "parallel2": (1, 2)}


def _write(path: Path, value: Any) -> None:
    """Write fresh evidence without replacing an earlier trial."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)


def _run(mode: str) -> None:
    """Run a complete nine-document trial using only native pipeline settings."""
    import torch
    from docling.datamodel.base_models import ConversionStatus, InputFormat
    from docling.datamodel.settings import settings, scoped
    from data_snapshot.evaluation.evaluate_model import evaluate
    from data_snapshot.evaluation.merge_batch_preds import combine_evaluation_files
    from data_snapshot.inference import docling_heron as adapter
    from data_snapshot.constants import LABEL_MAP
    from data_snapshot.utils import utc_now_iso
    from jsonschema import Draft202012Validator

    batch, concurrency = MODES[mode]
    root = OUTPUT / mode
    root.mkdir(parents=True)
    manifest = json.loads(
        (
            REPO / "src/data_snapshot/evaluation/configs/paper_benchmark_sample.json"
        ).read_text()
    )
    entries = manifest["documents"]
    dataset = REPO / "data/hf_datasets/data-snapshot"
    paths = [
        dataset / "documents" / entry["source"] / entry["pdf"] for entry in entries
    ]
    cfg = adapter.DoclingHeronConfig(
        artifacts_path=WORK / "artifacts", device="cuda:0", store_doc_path_as="absolute"
    )
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA unavailable; no CPU fallback")
    torch.cuda.init()
    torch.cuda.reset_peak_memory_stats()
    converter = adapter._make_converter(cfg)
    options = converter.format_to_options[InputFormat.PDF].pipeline_options
    options.layout_batch_size = batch
    perf = settings.perf.model_copy(
        update={
            "doc_batch_size": concurrency,
            "doc_batch_concurrency": concurrency,
        }
    )
    documents, predictions, raw_pages, completed = [], [], [], []
    source_pages: dict[str, list[dict[str, Any]]] = {}
    started = time.perf_counter()
    with scoped(perf=perf):
        converter.initialize_pipeline(InputFormat.PDF)
        initialized_seconds = time.perf_counter() - started
        for entry, path, result in zip(
            entries, paths, converter.convert_all(paths), strict=True
        ):
            if result.status != ConversionStatus.SUCCESS or result.errors:
                raise RuntimeError(
                    f"Failed {path.name}: {result.status}; {result.errors}"
                )
            expected = result.input.page_count
            assert [page.page_no for page in result.pages] == list(
                range(1, expected + 1)
            )
            assert result.input.file.name == path.name
            document = {
                "doc_id": path.name,
                "doc_name": path.name,
                "doc_path": str(path.resolve()),
            }
            documents.append(document)
            page_entries = []
            for page in result.pages:
                page_id = f"{path.name}::p{page.page_no - 1:03d}"
                objects = adapter._objects_from_page(
                    page, page_id=page_id, filter_small=True
                )
                if objects:
                    page_entries.append(
                        {
                            "page_id": page_id,
                            "doc_id": path.name,
                            "page_index": page.page_no - 1,
                            "objects": objects,
                        }
                    )
                raw_pages.append(
                    {
                        "doc_id": path.name,
                        "page_index": page.page_no - 1,
                        "clusters": [
                            {
                                "id": c.id,
                                "label": c.label.value,
                                "confidence": c.confidence,
                                "bbox": c.bbox.model_dump(mode="json"),
                            }
                            for c in page.predictions.layout.clusters
                        ],
                    }
                )
            predictions.extend(page_entries)
            source_pages.setdefault(entry["source"], []).extend(page_entries)
            native = result.document.export_to_dict()
            _write(root / "native" / f"{path.name}.json", native)
            counts = {"captions": 0, "footnotes": 0}
            for item in [*result.document.pictures, *result.document.tables]:
                for field in counts:
                    refs = getattr(item, field)
                    for ref in refs:
                        ref.resolve(result.document)
                    counts[field] += len(refs)
            timings = {
                name: sum(timing.times) for name, timing in result.timings.items()
            }
            completed.append(
                {
                    "doc_id": path.name,
                    "source": entry["source"],
                    "pages": expected,
                    "native_links": counts,
                    "timing_seconds": timings,
                    "elapsed_trial_seconds": time.perf_counter() - started,
                }
            )
            _write(root / "progress" / f"{path.name}.json", completed[-1])
            print(
                f"{mode}: {len(completed)}/9 PDFs, {sum(row['pages'] for row in completed)} pages, "
                f"{time.perf_counter() - started:.1f}s",
                flush=True,
            )
    torch.cuda.synchronize()
    elapsed = time.perf_counter() - started
    assert len(completed) == 9 and sum(row["pages"] for row in completed) == 170
    info = {
        "schema_version": "1.3",
        "type": "prediction",
        "created_at": utc_now_iso(),
        "run_id": f"docling-nine-{mode}",
        "model": {
            "name": adapter.MODEL_NAME,
            "version": adapter.MODEL_REVISION,
            "notes": f"native Docling; FP32; layout_batch={batch}; document_concurrency={concurrency}; shared area filter 0.008",
        },
        "coordinate_system": {
            "type": "normalized_xyxy",
            "range": [0.0, 1.0],
            "origin": "top_left",
        },
    }
    data = {
        "label_map": LABEL_MAP,
        "info": info,
        "documents": documents,
        "predictions": predictions,
    }
    Draft202012Validator(
        json.loads((REPO / "docs/data-snapshot-eval-v1.3.schema.json").read_text())
    ).validate(data)
    _write(root / "predictions.json", data)
    _write(root / "native-layout.json", raw_pages)
    sources = list(dict.fromkeys(entry["source"] for entry in entries))
    for source in sources:
        ids = {entry["pdf"] for entry in entries if entry["source"] == source}
        subset = {
            **data,
            "documents": [doc for doc in documents if doc["doc_id"] in ids],
            "predictions": source_pages[source],
        }
        pred_path = root / "predictions/sources" / f"{source}.json"
        _write(pred_path, subset)
        gt_path = root / "ground_truth/sources" / f"{source}.json"
        combine_evaluation_files(
            [
                dataset / "annotations" / source / entry["annotation"]
                for entry in entries
                if entry["source"] == source
            ],
            gt_path,
        )
        report = evaluate(
            gt_path, pred_path, output_path=root / "reports/sources" / f"{source}.json"
        )
        assert report["documents_mismatch"] == {"only_gt": [], "only_pred": []}
    gt_path = root / "ground_truth/corpus.json"
    combine_evaluation_files(
        [root / "ground_truth/sources" / f"{source}.json" for source in sources],
        gt_path,
    )
    report = evaluate(
        gt_path, root / "predictions.json", output_path=root / "reports/corpus.json"
    )
    assert report["documents_mismatch"] == {"only_gt": [], "only_pred": []}
    summary = {
        "mode": mode,
        "layout_batch_size": batch,
        "document_concurrency": concurrency,
        "documents": 9,
        "pages": 170,
        "elapsed_init_convert_export_seconds": elapsed,
        "initialization_seconds": initialized_seconds,
        "process_peak_rss_mib": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        / 1024,
        "torch_peak_allocated_mib": torch.cuda.max_memory_allocated() / 2**20,
        "torch_peak_reserved_mib": torch.cuda.max_memory_reserved() / 2**20,
        "completed": completed,
        "limits": "One trial per setting; wall time includes model initialization and native JSON export, excludes evaluation and interpreter imports; GPU memory covers PyTorch only.",
    }
    _write(root / "summary.json", summary)
    print(
        json.dumps(
            {key: value for key, value in summary.items() if key != "completed"},
            indent=2,
        ),
        flush=True,
    )


def main() -> None:
    """Choose one complete nine-PDF trial; all outputs are protected."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=MODES)
    _run(parser.parse_args().mode)


if __name__ == "__main__":
    main()
